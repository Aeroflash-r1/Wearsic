package com.wearsic.server

import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.engine.cio.CIO
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.request.get
import io.ktor.client.request.parameter
import io.ktor.serialization.kotlinx.json.json
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

@Serializable
data class ITunesTrack(
    val trackId: Long,
    val trackName: String? = null,
    val artistName: String? = null,
    val trackTimeMillis: Long? = null,
    val artworkUrl100: String? = null,
) {
    /** Prefixed so the stream endpoint can tell "needs YouTube matching" apart from a real videoId. */
    val surrogateId: String get() = "$SURROGATE_PREFIX$trackId"

    fun artworkUrl(size: Int = 300): String? =
        artworkUrl100?.replace("100x100bb", "${size}x${size}bb")

    companion object {
        const val SURROGATE_PREFIX = "it:"
    }
}

@Serializable
private data class ITunesSearchResponse(
    val resultCount: Int = 0,
    val results: List<ITunesTrack> = emptyList(),
)

/** No API key/registration needed — this is iTunes' public, unauthenticated search endpoint. */
class ITunesService {

    private val client = HttpClient(CIO) {
        install(ContentNegotiation) { json(Json { ignoreUnknownKeys = true }) }
    }

    suspend fun searchSongs(query: String, limit: Int = 10): List<ITunesTrack> {
        if (query.isBlank()) return emptyList()
        return runCatching {
            client.get("https://itunes.apple.com/search") {
                parameter("term", query)
                parameter("media", "music")
                parameter("entity", "song")
                parameter("limit", limit)
            }.body<ITunesSearchResponse>()
                .results
                .filter { it.trackName != null && it.artistName != null }
        }.getOrDefault(emptyList())
    }

    fun toTrackDto(track: ITunesTrack): TrackDto = TrackDto(
        videoId = track.surrogateId,
        title = track.trackName ?: "Unknown",
        uploader = track.artistName ?: "Unknown",
        durationMs = track.trackTimeMillis ?: 0L,
        // Served at a modest size deliberately — iTunes' mzstatic.com URLs
        // don't match the client's existing ytimg/googleusercontent
        // upscale regex, so unlike YouTube thumbnails these won't get
        // upscaled client-side. 300px is a reasonable fixed size for a
        // watch screen without over-fetching.
        thumbnailUrl = track.artworkUrl(300),
    )
}
