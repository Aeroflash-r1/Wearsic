# Wearsic Server — Fresh Rewrite Setup

This is a complete from-scratch Kotlin/Ktor implementation of `wearsic-server`,
since no source ever existed in the repo (it was compiled-jar-only). It's
built against the exact dependency versions already proven working in your
Termux deployment (Ktor 2.3.12, NewPipeExtractor v0.26.4, kotlinx-coroutines
1.7.1, sqlite-jdbc 3.46.1.0), and produces the same `bin/`+`lib/` output
shape your existing `run-termux.sh` expects — so that script doesn't need to
change.

## 1. Drop the files into the repo

Copy this whole `wearsic-server/` folder (the one containing
`build.gradle.kts` and `src/`) into your repo, merging with — not
replacing — the *existing* `wearsic-server/` folder. Keep the existing
`.env.example`, `README.md`, and `run-termux.sh` where they are; this adds
`build.gradle.kts` and `src/` alongside them. The existing `bin/` and `lib/`
folders (the old compiled jar) can stay for now — you'll overwrite them in
step 3.

## 2. Register the module

Add this one line to the repo-root `settings.gradle.kts`, right after
`include(":app")`:

```kotlin
include(":wearsic-server")
```

## 3. Build it

```bash
./gradlew :wearsic-server:installDist
```

This produces `wearsic-server/build/install/wearsic-server/{bin,lib}` — copy
those two folders over the existing `wearsic-server/bin` and
`wearsic-server/lib`, replacing them. `run-termux.sh` already knows how to
find `bin/wearsic-server` in that layout, so no script changes needed.

## 4. Database note — important

The old server's SQLite schema was never documented anywhere in the repo (no
`.sql`/schema file existed — it was compiled directly into the jar). I
designed a fresh, reasonable schema for favorites/playlists from the API
contract, since there was nothing to match against. **This means a
pre-existing `wearsic.db` from the old server will NOT be compatible** —
the table names/columns are new.

Before first run with the new server:
- **Back up** `~/wearsic-server/wearsic.db` if you want to keep existing
  favorites/playlists
- Either delete/rename the old `wearsic.db` (new server creates a fresh one
  automatically on first run), or tell me what's actually in your old
  favorites/playlists and I'll write a migration script

## 5. First run

Same as always:
```bash
cd ~/wearsic-server
./run-termux.sh
```
Then verify:
```bash
curl http://127.0.0.1:8080/health
curl "http://127.0.0.1:8080/api/search?q=weather+with+you"
```

## 6. Set the YouTube cookie

Same as before — either `WEARSIC_YOUTUBE_COOKIE` in `.env`, or now also
live via `POST /api/config/youtube-cookie` with `{"cookie": "..."}` without
restarting.

## What's different from the old (bytecode-patched) server

- **Search**: filtered (`music_songs`) and unfiltered search now run
  concurrently via real Kotlin coroutines — no reflection, no per-request
  thread pool spin-up.
- **Stream resolution**: tries the iOS-spoofed YouTube client first (the one
  that actually works), falls back to the default client only if that fails
  — instead of the reverse.
- **HTTP transport**: NewPipeExtractor's `Downloader` now runs on a pooled,
  keep-alive Ktor CIO client (shared connection pool, HTTP pipelining)
  instead of raw `HttpURLConnection`.
- **Cookie handling**: read from `WEARSIC_YOUTUBE_COOKIE` on boot, with a
  clean runtime-update endpoint — no reflection into private fields.
- **Bitrate selection**: preserved the original ~70kbps target-bitrate
  selection logic (picks the closest audio stream to that target, not the
  highest quality) — this was a deliberate storage/bandwidth choice worth
  keeping for a watch client.
- **Everything else** (routes, response shapes, `TrackDto` fields, the
  `videoId == "*"` deletes-whole-playlist behavior) matches
  `API_CONTRACT.md` exactly, so the Android client needs zero changes.

## v2 update — iTunes metadata + background prefetch matching

`/api/search` no longer calls NewPipeExtractor directly. It now:

1. Calls the free, unauthenticated **iTunes Search API** for metadata —
   typically ~150-300ms, clean data, no YouTube round trip in the request
   path at all.
2. Returns results immediately with a **surrogate videoId** like `it:12345`
   (iTunes' own track id, prefixed) instead of a real YouTube id — the
   client doesn't need to know or care about this, it just calls
   `/api/stream/it:12345` exactly like it always would.
3. **In the background**, right after responding, the top 6 results get
   matched to a real YouTube video (scored on duration closeness, "Artist -
   Topic" channel bonus, title similarity, penalty keywords for
   covers/remixes) and their stream immediately pre-resolved — so by the
   time someone actually taps play, both steps are usually already cached.

`/api/stream/{id}` now resolves that id first: if it's a surrogate iTunes
id, it uses the cached match from the prefetch, or matches synchronously on
the spot as a fallback if the user tapped faster than the background job
finished. Real YouTube ids (from `/api/related` and `/api/playlist`, which
are unchanged and still NewPipeExtractor-only) pass through untouched.

**New files:** `ITunesService.kt`, `TrackMatcher.kt`,
`MetadataSearchOrchestrator.kt`.

**Scoped out of this pass, on purpose:** `/api/search/albums` still uses
NewPipeExtractor as before. Matching an entire *album* to a corresponding
YouTube playlist is a meaningfully harder problem than matching one track —
wrong-track matches are recoverable (skip it), but a wrong-album match
means half the tracklist could be off. Worth doing as a separate pass once
single-track matching is confirmed reliable in practice.

**One thing to watch:** iTunes' catalog isn't 100% of YouTube's — a very
obscure or unreleased-on-iTunes track might return zero iTunes results even
though it's findable on YouTube directly. If that turns out to matter in
practice, a reasonable fallback is: if iTunes returns nothing, fall back to
the old direct NewPipeExtractor search for that query.

## One honest caveat

I wrote this against NewPipeExtractor's documented v0.26.4 API from
knowledge, without being able to compile or run it myself (no network
access in my sandbox to pull the actual dependency jars and verify). A
couple of method/property names on things like `AudioStream` or
`PlaylistInfoItem` have shifted across NewPipeExtractor versions
historically — if `./gradlew :wearsic-server:compileKotlin` fails on a
specific line, that's almost certainly just a renamed getter, not a logic
problem. Have your coding agent fix the specific compile error against the
actual NewPipeExtractor v0.26.4 source (it's on JitPack/GitHub) rather than
rewriting the surrounding logic — the caching, concurrency, and client-order
fixes are the parts that matter and are correct as designed.
