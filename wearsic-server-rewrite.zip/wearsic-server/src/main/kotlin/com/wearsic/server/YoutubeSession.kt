package com.wearsic.server

import java.util.concurrent.atomic.AtomicReference

/**
 * Holds the YouTube cookie used to avoid the "bot-challenged server IP"
 * problem noted in .env.example. Falls back to the WEARSIC_YOUTUBE_COOKIE
 * env var on boot, but can be updated at runtime via POST /api/config/youtube-cookie
 * without restarting the server.
 */
object YoutubeSession {

    private fun envFallbackCookie(): String? =
        System.getenv("WEARSIC_YOUTUBE_COOKIE")?.trim()?.takeIf { it.isNotEmpty() }

    private val cookieRef = AtomicReference(envFallbackCookie())

    var cookie: String?
        get() = cookieRef.get()
        set(value) {
            cookieRef.set(value?.trim()?.takeIf { it.isNotEmpty() })
        }

    fun hasCookie(): Boolean = cookie != null
}
