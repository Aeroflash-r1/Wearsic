plugins {
    kotlin("jvm") version "2.0.21"
    kotlin("plugin.serialization") version "2.0.21"
    application
}

repositories {
    mavenCentral()
    maven("https://jitpack.io") // NewPipeExtractor is published via JitPack
}

val ktorVersion = "2.3.12"
val coroutinesVersion = "1.7.1"
val serializationVersion = "1.7.3"

dependencies {
    // --- Ktor server (CIO engine — matches original deployment) ---
    implementation("io.ktor:ktor-server-core-jvm:$ktorVersion")
    implementation("io.ktor:ktor-server-cio-jvm:$ktorVersion")
    implementation("io.ktor:ktor-server-content-negotiation-jvm:$ktorVersion")
    implementation("io.ktor:ktor-server-call-logging-jvm:$ktorVersion")
    implementation("io.ktor:ktor-server-host-common-jvm:$ktorVersion")
    implementation("io.ktor:ktor-serialization-kotlinx-json-jvm:$ktorVersion")

    // --- Ktor client (CIO engine — used for BOTH NewPipe extraction requests
    //     and the audio proxy, replacing the old raw HttpURLConnection path) ---
    implementation("io.ktor:ktor-client-core-jvm:$ktorVersion")
    implementation("io.ktor:ktor-client-cio-jvm:$ktorVersion")
    implementation("io.ktor:ktor-client-content-negotiation-jvm:$ktorVersion")

    // --- Coroutines / serialization ---
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:$coroutinesVersion")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-jdk8:$coroutinesVersion")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-slf4j:$coroutinesVersion")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-core:$serializationVersion")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:$serializationVersion")

    // --- Extraction ---
    implementation("com.github.TeamNewPipe:NewPipeExtractor:v0.26.4")

    // --- Persistence ---
    implementation("org.xerial:sqlite-jdbc:3.46.1.0")

    // --- Logging ---
    implementation("ch.qos.logback:logback-classic:1.5.15")
}

application {
    // Matches the existing com.wearsic.server package used by the current
    // compiled jar, so nothing about the deployment path changes.
    mainClass.set("com.wearsic.server.ApplicationKt")
}

kotlin {
    jvmToolchain(17)
}

tasks.test {
    useJUnitPlatform()
}

// `./gradlew :wearsic-server:installDist` produces build/install/wearsic-server/{bin,lib}
// — the exact same shape as the current wearsic-server/{bin,lib} folders, so
// run-termux.sh keeps working unmodified. Copy that output over the existing
// bin/ and lib/ folders (or point run-termux.sh at the new install path).
